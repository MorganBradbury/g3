﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace G3.Models.Return
{
    public class UpdateVehicleModel
    {
        public int vehicleId { get; set; }

        public decimal Price { get; set; }
    }
}
