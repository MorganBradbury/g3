﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace G3.Models
{
    public class VehicleGetModel : PagingModel
    {
        public int UserId { get; set; }
    }
}
