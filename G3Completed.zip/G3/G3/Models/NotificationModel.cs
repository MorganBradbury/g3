﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace G3.Models
{
    public class NotificationModel
    {
        public int userId { get; set; }

        public int vehicleId { get; set; }
    }
}
