﻿using G3.DAL;
using G3.DAL.Models;
using G3.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace G3.Process
{
    public interface INotificationProcessor
    {
        IEnumerable<Notification> GetNotifications(int userId);
        Notification CreateNotification(NotificationModel notification);
        Notification ReadNotification(int notificationId);
    }
    public class NotificationProcessor : INotificationProcessor
    {

        private readonly Context _context;

        public NotificationProcessor(Context context)
        {
            _context = context;
        }

        public IEnumerable<Notification> GetNotifications(int userId)
        {
            return _context.Notifications.Where(x => x.UserId == userId);
        }

        public Notification CreateNotification(NotificationModel notification)
        {
            if(notification.userId != 0 && notification.userId.ToString() != null)
            {
                Notification CreateNotification = new Notification() {
                    NotificationId = _context.Notifications.Count() > 0 ? (
                        _context.Notifications.Select(x => x.NotificationId).Max() + 1) : 1,
                    UserId = notification.userId,
                    Read = false,
                    Vehicle = _context.Vehicles.Where(x => x.VehicleId == notification.vehicleId).FirstOrDefault(),
                    Body = "Price Updated",
                    Title = "Tracked Vehicle " + _context.Vehicles.Where(x => x.VehicleId == notification.vehicleId).FirstOrDefault().Vrm + "'s price has been updated!"
                };

                _context.Notifications.Add(CreateNotification);
                _context.SaveChanges();

                return CreateNotification;
            }
            else
            {
                return null;
            }
        }

        public Notification ReadNotification(int notificationId)
        {
            if(notificationId > 0)
            {
                try
                {
                    Notification notification = _context.Notifications.Where(x => x.NotificationId == notificationId).First();
                    notification.Read = true;
                    _context.Notifications.Update(notification);
                    _context.SaveChanges();

                    return notification;
                }
                catch
                {
                    return null;
                }
            }
            else
            {
                return null;
            }

        }
    }
}
