﻿using G3.DAL;
using G3.DAL.Models;
using G3.Models.Return;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using G3.Controllers;
using G3.Models;

namespace G3.Process
{
    public interface IEditVehicleProcessor
    {
        Vehicle EditVehicle(UpdateVehicleModel vehicle);
    }
    public class EditVehicleProcessor : IEditVehicleProcessor
    {

        private readonly Context _context;
        private readonly INotificationProcessor _notificationProcessor;

        public EditVehicleProcessor(Context context, INotificationProcessor notificationProcessor)
        {
            _context = context;
            _notificationProcessor = notificationProcessor;
        }

        public Vehicle EditVehicle(UpdateVehicleModel vehicle)
        {
            Vehicle updatedVehicle = _context.Vehicles.Where(x => x.VehicleId == vehicle.vehicleId).FirstOrDefault();
            if(vehicle.Price > 0 && (vehicle.Price % 25 == 0))
            {
                updatedVehicle.Price = vehicle.Price;
                _context.Update(updatedVehicle);
                _context.SaveChanges();


                // Once vehicle has been updated, notify all users.
                foreach(UserVehicleWatch FindVehicles in _context.UserVehicleWatches.Where(x => x.VehicleId == vehicle.vehicleId))
                {
                    NotificationModel notification = new NotificationModel()
                    {
                        userId = FindVehicles.UserId,
                        vehicleId = vehicle.vehicleId
                    };

                    _notificationProcessor.CreateNotification(notification);

                }

                return updatedVehicle;
            }
            else
            {
                return null;
            }


        }
    }
}
