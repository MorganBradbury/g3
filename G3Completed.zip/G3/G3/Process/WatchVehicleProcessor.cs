﻿using G3.DAL;
using G3.DAL.Models;
using G3.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace G3.Process
{
    public interface IWatchVehicleProcessor
    {
        IEnumerable<Vehicle> GetVehicles(int vehicleId);
        UserVehicleWatch ToggleWatchVehicle(int vehicleId, int userId);
        IEnumerable<UserVehicleWatch> GetActiveTrackedByUser(int userId);

    }

    public class WatchVehicleProcessor : IWatchVehicleProcessor
    {

        private readonly Context _context;

        public WatchVehicleProcessor(Context context)
        {
            _context = context;
        }

        public IEnumerable<Vehicle> GetVehicles(int vehicleId)
        {
            if(vehicleId == 0)
            {
                return _context.Vehicles;
            }
            else
            {
                 return _context.Vehicles.Where(x => x.VehicleId == vehicleId);
            }

        }


        public IEnumerable<UserVehicleWatch> GetActiveTrackedByUser(int userId)
        {
            // Return list of all user vehicle watches where they are Active.
            return _context.UserVehicleWatches.Where(
                x => x.UserId == userId
                && x.Active == true
            );
        }

        public UserVehicleWatch ToggleWatchVehicle(int userId, int vehicleId)
        {
            // This method is going to "watch" a vehicle. Pass in user ID and Vehicle ID and then create a record in the in-memory database. Use the object for UserVehicleWatch
            try
            {
                UserVehicleWatch userVehicleWatch = new UserVehicleWatch();

                // Check to ensure the Vehicle hasnt already been toggled for Watching. If so, 
                if (_context.UserVehicleWatches.Count(x => x.VehicleId == vehicleId && x.UserId == userId) > 0)
                {
                    try
                    {

                        userVehicleWatch = _context.UserVehicleWatches.Where(x => x.UserId == userId && x.VehicleId == vehicleId).First();
                        if (userVehicleWatch.Active == true)
                        {
                            userVehicleWatch.Active = false;
                        }
                        else
                        {
                            userVehicleWatch.Active = true;
                        }
                            _context.UserVehicleWatches.Update(userVehicleWatch);
                            _context.SaveChanges();

                            // Matches criteria and updated.
                            return userVehicleWatch;
                    }
                    catch
                    {
                        // If we got here, there was a problem. Return false.
                        return null;
                    }
                }

                // Create new UserVehicleWatch Object and bind all needed data
                // If this is the first watch created, ID would be 1. Otherwise work out ID by Data set.
                userVehicleWatch.WatchId = _context.UserVehicleWatches.Count() > 0 ? (
                    _context.UserVehicleWatches.Select(x => x.WatchId).Max() + 1) : 1;
                userVehicleWatch.UserId = userId;
                userVehicleWatch.VehicleId = vehicleId;
                userVehicleWatch.Active = true;
                userVehicleWatch.User = _context.Users.Where(x => x.UserId == userId).First(); // Find user by ID
                userVehicleWatch.Vehicle = _context.Vehicles.Where(x => x.VehicleId == vehicleId).First(); // Find Vehicle by ID

                // Add to In memory DB and Save.
                _context.UserVehicleWatches.Add(userVehicleWatch);
                _context.SaveChanges();

                // Watch has been added into Data. Return true.
                return userVehicleWatch;
            }
            catch
            {
                // If we got here, there was a problem. Return false.
                return null;
            }
        }
    }
}
