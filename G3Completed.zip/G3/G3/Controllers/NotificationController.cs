﻿using G3.DAL;
using G3.DAL.Models;
using G3.Models;
using G3.Process;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace G3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NotificationController : ControllerBase
    {
        private readonly INotificationProcessor _notificationProcesser;

        public NotificationController(Context context, INotificationProcessor notificationProcesser)
        {
            // Notification Processer. All methods for Notifications can be found here.
            _notificationProcesser = notificationProcesser;
        }

        // Return a list of ALL Notifications.
        [Route("[action]/{userId}")]
        [HttpGet(Name = "GetNotifications")]
        public ActionResult<IEnumerable<Notification>> GetNotifications(int userId)
        {
            // Get a list of all Notifications which match the userId provided.
            var getNotifications = _notificationProcesser.GetNotifications(userId);

            if (getNotifications != null)
            {
                // If list is not empty, return the list.
                return Ok(getNotifications);

            }
            else
            {
                // Something went wrong. List is empty.
                return BadRequest();
            }
        }

        // Insert a notification into Notifications table.
        // This can be used as an API for testing but is also called inside the VehicleControler. See references.
        [Route("[action]")]
        [HttpPost(Name = "CreateNotification")]
        public ActionResult<Notification> CreateNotification([FromBody] NotificationModel notification)
        {
            // Create notification using NotificationModel data.
            Notification createdNotification = _notificationProcesser.CreateNotification(notification);
            if (createdNotification != null)
            {
                // Return the created notification.
                return createdNotification;
            }
            else
            {
                // Something went wrong. Return 400 Response.
                return BadRequest();
            }
        }

        [Route("[action]/{notificationId}")]
        [HttpPost(Name = "ReadNotification")]
        public ActionResult<Notification> ReadNotification(int notificationId)
        {
            // Set a specific notification as read by ID.
            Notification readNotification = _notificationProcesser.ReadNotification(notificationId);
            if (readNotification != null)
            {
                // Return Notification object with updated values.
                return readNotification;
            }
            else
            {
                // Something went wrong. Return 400 Response.
                return BadRequest();
            }
        }
    }
}
