﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using G3.DAL;
using G3.DAL.Models;
using G3.Models;
using G3.Models.Return;
using G3.Process;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.FileSystemGlobbing;

namespace G3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VehicleController : ControllerBase
    {
        private readonly IWatchVehicleProcessor _watchProcessor;
        private readonly IEditVehicleProcessor _editProcessor;

        public VehicleController(Context context, IWatchVehicleProcessor watchProcessor, IEditVehicleProcessor editProcesser)
        {
            _watchProcessor = watchProcessor;
            _editProcessor = editProcesser;
        }

        // Return a list of ALL Vehicles.
        [Route("[action]")]
        [HttpGet(Name = "GetVehicles")]
        public IEnumerable<Vehicle> GetVehicles(int vehicleId)
        {
            // If no vehicle Id, return all results set. Otherwise return specific vehicle.
            var getVehicles = _watchProcessor.GetVehicles(vehicleId);
            return getVehicles;
        }



        // Method for Tracking vehicle.
        [Route("[action]/{userId}/{vehicleId}")]
        [HttpPost(Name = "ToggleWatchVehicle")]
        public ActionResult<bool> ToggleWatchVehicle(int userId, int vehicleId)
        {
            // Trigger watch. If created, return true.
            var watchVehicle = _watchProcessor.ToggleWatchVehicle(userId, vehicleId);
            if (watchVehicle != null)
            {
                return Ok(true);
            }
            else
            {
                return BadRequest(false);
            }
        }


        [Route("[action]")]
        [HttpGet(Name = "UpdateVehicle")]
        public ActionResult<bool> UpdateVehicle([FromBody] UpdateVehicleModel vehicle)
        {
            // Update details of Vehicle.
            Vehicle editedVehicle = _editProcessor.EditVehicle(vehicle);
            if(editedVehicle != null)
            {
                return Ok(true);
            }
            else
            {
                return BadRequest();
            }
        }
    }
}
